//
//  ViewController.swift
//  HeadorTail
//
//  Created by Sonar on 10/18/18.
//  Copyright © 2018 Sonar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var resultLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func flipBtn(_ sender: Any) {
      var  options = ["Head","Tail"]
      //  print (options)
       self.resultLbl.text = (options.randomElement()!)
    }
    
}

